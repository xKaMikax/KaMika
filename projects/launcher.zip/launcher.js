'use strict';

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const { Client, Authenticator } = require('minecraft-launcher-core');
const { Authflow } = require('prismarine-auth');

// ---------- CLI ----------
const args = process.argv.slice(2);
const getArg = (name, def) => {
  const flag = '--' + name;
  const i = args.findIndex(a => a === flag);
  return (i !== -1 && args[i + 1] && !args[i + 1].startsWith('--')) ? args[i + 1] : def;
};

const MC_VERSION   = getArg('version', null);
const RAM          = getArg('ram', '4G');
const ROOT         = path.resolve(getArg('dir', path.join(process.cwd(), 'minecraft')));
const OFFLINE_NICK = getArg('offline', null);
const JAVA_PATH    = getArg('java', null); // <-- новый флаг
const AUTH_CACHE   = path.join(ROOT, '.auth');

fs.mkdirSync(ROOT, { recursive: true });
fs.mkdirSync(AUTH_CACHE, { recursive: true });

// ---------- helpers ----------
function runJavaVersion(javaPath) {
  const exe = javaPath || 'java';
  const r = spawnSync(exe, ['-version'], { encoding: 'utf8' });
  return { err: r.error || null, out: (r.stderr || r.stdout || '') };
}

function parseJavaMajor(verText) {
  // примеры: 'openjdk version "21.0.4"...', 'java version "17.0.12"...'
  const m = /version\s+"(\d+)\.(\d+)\.(\d+)"/i.exec(verText) || /version\s+"(\d+)"/i.exec(verText);
  if (!m) return null;
  const major = parseInt(m[1], 10);
  return isNaN(major) ? null : major;
}

function parseMcSemver(v) {
  // '1.21.1' -> {major:1, minor:21, patch:1}
  const m = /^(\d+)\.(\d+)(?:\.(\d+))?/.exec(String(v));
  if (!m) return null;
  return { major: +m[1], minor: +m[2], patch: +(m[3] || 0) };
}

function needsJava21(mcVer) {
  // начиная с 1.20.5 нужна Java 21
  const s = parseMcSemver(mcVer);
  if (!s) return false;
  return (s.minor > 20) || (s.minor === 20 && s.patch >= 5);
}

// ---------- проверка Java (с учётом флага --java) ----------
(function checkJava() {
  const { err, out } = runJavaVersion(JAVA_PATH);
  if (err) {
    console.log('[!] Java не найдена' + (JAVA_PATH ? ' по пути: ' + JAVA_PATH : '') + '. Поставьте Java 21+ (x64) и/или укажите --java "C:\\...\\java.exe".');
    process.exit(1);
  }
})();

// ---------- helper: открыть URL в браузере (ESM-пакет "open") ----------
async function openInBrowser(url) {
  try {
    const { default: open } = await import('open');
    await open(url);
  } catch {}
}

// ---------- Microsoft login (Device Code) ----------
async function loginMicrosoft() {
  console.log('[Auth] Вход Microsoft (device code)...');
  const flow = new Authflow(
    'default-user',
    AUTH_CACHE,
    undefined,
    (code) => {
      console.log('================ MICROSOFT LOGIN ================');
      console.log('Зайдите на: ' + code.verification_uri);
      console.log('Введите код: ' + code.user_code);
      console.log('(Ссылка откроется автоматически.)');
      console.log('==================================================');
      openInBrowser(code.verification_uri);
    }
  );

  const mc = await flow.getMinecraftJavaToken({ fetchProfile: true });
  if (!mc || !mc.profile) throw new Error('Не удалось получить профиль Minecraft.');

  return {
    access_token: mc.token,
    client_token: crypto.randomUUID().replace(/-/g, ''),
    uuid: mc.profile.id,
    name: mc.profile.name,
    user_properties: '{}',
    meta: { type: 'msa', demo: false }
  };
}

// ---------- main ----------
async function main() {
  const launcher = new Client();

  // Версия: если не указана — берём последнюю release
  let versionNumber = MC_VERSION;
  if (!versionNumber) {
    try {
      const res = await fetch('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json');
      const manifest = await res.json();
      versionNumber = (manifest && manifest.latest && manifest.latest.release) ? manifest.latest.release : '1.20.6';
      console.log('[Info] Версия для запуска: ' + versionNumber);
    } catch {
      versionNumber = '1.20.6';
      console.log('[Info] Использую запасную версию: ' + versionNumber);
    }
  }

  // Предупреждение по версии Java
  const { out: jvOut } = runJavaVersion(JAVA_PATH);
  const javaMajor = parseJavaMajor(jvOut);
  if (javaMajor && needsJava21(versionNumber) && javaMajor < 21) {
    console.log('[!] Требуется Java 21 для Minecraft ' + versionNumber + '. Сейчас обнаружена Java ' + javaMajor + '.');
    console.log('    Укажи путь к Java 21 флагом --java "C:\\Program Files\\...\\jdk-21\\bin\\java.exe" или обнови PATH.');
    process.exit(1);
  }

  // Авторизация
  let authorization;
  if (OFFLINE_NICK) {
    console.log('[Auth] Оффлайн-режим, ник: ' + OFFLINE_NICK + ' (мультиплеер на лиц. серверах недоступен)');
    authorization = Authenticator.getAuth(OFFLINE_NICK);
  } else {
    try {
      authorization = await loginMicrosoft();
    } catch (e) {
      const msg = (e && e.message) ? e.message : String(e);
      if (msg.toLowerCase().includes('first party application') || msg.toLowerCase().includes('invalid_request')) {
        console.error('\n[Auth] Microsoft отклонил вход этой учёткой.');
        console.error('Нужна ЛИЧНАЯ учётка Microsoft (MSA). Открой ссылку в Инкогнито и войди с Outlook/Hotmail.');
        console.error('Проверь, что создан Xbox-профиль под этой учёткой (зайди на xbox.com один раз).');
      } else {
        console.error('\n[Auth] Ошибка входа:', msg);
      }
      console.error('Подсказка: для проверки запуска можно оффлайн:  node launcher.js --offline Player');
      process.exit(1);
    }
  }

  const opts = {
    authorization,
    root: ROOT,
    version: { number: versionNumber, type: 'release' },
    memory: { max: RAM, min: RAM },
    timeout: 15000
  };
  if (JAVA_PATH) opts.javaPath = JAVA_PATH; // <-- используем указанную Java

  console.log('[Launch] Установка/проверка файлов игры...');
  launcher.launch(opts);

  launcher.on('debug', (e) => console.log('[debug]', e));
  launcher.on('data', (e) => process.stdout.write(String(e)));
  launcher.on('progress', (e) => {
    const p = (e && e.task && typeof e.task.percentage === 'number') ? e.task.percentage : 0;
    process.stdout.write('\r[download] ' + (e && e.type ? e.type : '') + ' ' + Math.round(p) + '%   ');
  });
  launcher.on('download-status', (e) => {
    process.stdout.write('\r[dl] files: ' + e.total + ' / ' + e.task + '     ');
  });
  launcher.on('close', (code) => {
    console.log('\n[Exit] Minecraft завершился с кодом:', code);
    process.exit((code === undefined || code === null) ? 0 : code);
  });
}

main().catch((err) => {
  console.error('\n[Fatal]', err && err.stack ? err.stack : err);
  process.exit(1);
});